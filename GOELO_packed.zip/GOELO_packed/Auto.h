#pragma once
#include "Imgui/imconfig.h"
#include "Imgui/imgui.h"
#include "Imgui/imgui_impl_dx11.h"
#include "Imgui/imgui_impl_win32.h"
#include "Imgui/imgui_internal.h"
#include "Imgui/imstb_truetype.h"
#include "Imgui/imstb_rectpack.h"
#include "Imgui/imstb_textedit.h"
#include "goplayer.h"
#include "FileManager.h"
#include "PlayerInputWindow.h"

#include <d3d11.h>
#pragma comment(lib, "d3d11.lib")